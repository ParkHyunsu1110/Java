package global;

import java.sql.Connection;
import java.sql.SQLException;

public class Main {
	private static Connection conn;
 
	public static void main(String[] args) {
//
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			conn = java.sql.DriverManager.getConnection("jdbc:mysql://localhost:3306/lms?serverTimezone=UTC&useSSL=false","root","adgjl13579");
			java.sql.Statement stmt = conn.createStatement();
			java.sql.ResultSet rs = stmt.executeQuery("select * from college");
			
			for(int i = 1; i<=2; i++) {
				rs.beforeFirst();
				
				while(rs.next()) {
					System.out.println(rs.getString("ID") + rs.getString("name"));
				}
				System.out.println("------------");
			}
			conn.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
