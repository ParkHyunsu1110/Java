package server;

public class Constant {
	public final static int PORTNUMBER = 10001;
	public final static String IP = "localhost";

}
